package com.hearassist.live.audio.dsp

class DspProcessor(sampleRate: Int = 48000) {
    private val eq = Equalizer(sampleRate)
    private val limiter = Limiter(-1.0f)
    var inputGain: Float = 1.0f
    var masterGain: Float = 0.3f // start low for safety
    var limiterEnabled: Boolean = true
    var muted: Boolean = false

    init {
        limiter.setSampleRate(sampleRate)
    }

    fun setEqGain(index: Int, gainDb: Float) {
        eq.setGain(index, gainDb)
    }

    fun getEqGains(): FloatArray = eq.getGains()

    fun resetEq() {
        eq.reset()
    }

    fun process(input: FloatArray): FloatArray {
        val out = FloatArray(input.size)
        if (muted) {
            return out
        }
        for (i in input.indices) {
            var x = (input[i].toDouble() * inputGain.toDouble())
            x = eq.process(x)
            x = x * masterGain.toDouble()
            if (limiterEnabled) {
                x = limiter.process(x)
            }
            // soft clamp as extra safety
            if (x > 0.999) x = 0.999
            if (x < -0.999) x = -0.999
            out[i] = x.toFloat()
        }
        return out
    }
}
