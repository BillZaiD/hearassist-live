package com.hearassist.live.ui.advanced

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hearassist.live.R
import com.hearassist.live.ui.theme.Background
import com.hearassist.live.ui.theme.Primary
import com.hearassist.live.ui.theme.Surface
import com.hearassist.live.ui.theme.Warning
import com.hearassist.live.ui.viewmodel.HearAssistViewModel

@Composable
fun AdvancedScreen(viewModel: HearAssistViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Filled.Settings, contentDescription = null, tint = Primary)
            Text(stringResource(R.string.advanced), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("معلومات الصوت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                InfoRow(label = stringResource(R.string.sample_rate), value = "48,000 Hz")
                InfoRow(label = stringResource(R.string.buffer_size), value = "~256 إطار (مُحسَّن)")
                InfoRow(label = stringResource(R.string.latency_estimate), value = "10 - 20 مللي ثانية (حسب الجهاز)")
                InfoRow(label = stringResource(R.string.limiter), value = "مُفعَّل")
                InfoRow(label = stringResource(R.string.compression), value = "معطَّل")
                InfoRow(label = stringResource(R.string.noise_reduction), value = "تجريبي / معطَّل")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Info, contentDescription = null, tint = Primary)
                    Text(stringResource(R.string.troubleshooting), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                Text("• ${stringResource(R.string.warning_headphones)}")
                Text("• تأكد من منح إذن الميكروفون")
                Text("• يفضل استخدام سماعات سلكية أو USB-C للحصول على أفضل أداء")
                Text("• بعض الأجهزة لا تدعم التقاط الميكروفون وتشغيل الصوت معًا بشكل موثوق")
                Text("• في حالة عدم وجود صوت، جرب إيقاف وإعادة بدء الاستماع")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Warning.copy(alpha = 0.1f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.safety_notice), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = Warning)
                Text(stringResource(R.string.safety_text), style = MaterialTheme.typography.bodySmall, lineHeight = 18.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
