package com.hearassist.live.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Process
import com.hearassist.live.audio.dsp.DspProcessor
import java.util.concurrent.atomic.AtomicBoolean

class AudioThread(
    private val sampleRate: Int = 48000,
    private val bufferFrames: Int = 256
) : Thread("HearAssistAudio") {
    private val running = AtomicBoolean(false)
    private val dsp = DspProcessor(sampleRate)
    var inputGain: Float
        get() = dsp.inputGain
        set(v) { dsp.inputGain = v.coerceIn(0.0f, 4.0f) }
    var masterGain: Float
        get() = dsp.masterGain
        set(v) { dsp.masterGain = v.coerceIn(0.0f, 1.0f) }
    var muted: Boolean
        get() = dsp.muted
        set(v) { dsp.muted = v }

    init {
        AudioLink.dspProcessor = dsp
        AudioLink.applyAllToProcessor()
    }

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null

    override fun run() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val channelIn = AudioFormat.CHANNEL_IN_MONO
        val channelOut = AudioFormat.CHANNEL_OUT_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minIn = AudioRecord.getMinBufferSize(sampleRate, channelIn, encoding)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, channelOut, encoding)
        val inBuf = ShortArray(maxOf(minIn / 2, bufferFrames))
        val outBuf = ShortArray(maxOf(minOut / 2, bufferFrames))

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelIn,
                encoding,
                inBuf.size * 2
            )
            val attr = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(encoding)
                .setSampleRate(sampleRate)
                .setChannelMask(channelOut)
                .build()
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(attr)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(outBuf.size * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            audioTrack?.play()
            audioRecord?.startRecording()
            running.set(true)
            while (running.get()) {
                val read = audioRecord?.read(inBuf, 0, inBuf.size) ?: -1
                if (read <= 0) continue
                val floatIn = FloatArray(read)
                for (i in 0 until read) {
                    floatIn[i] = inBuf[i].toFloat() / 32768.0f
                }
                val floatOut = dsp.process(floatIn)
                for (i in 0 until read) {
                    var v = floatOut[i] * 32767.0f
                    if (v > 32767.0f) v = 32767.0f
                    if (v < -32768.0f) v = -32768.0f
                    outBuf[i] = v.toInt().toShort()
                }
                audioTrack?.write(outBuf, 0, read)
            }
        } finally {
            stopInternal()
        }
    }

    fun start() {
        if (!isAlive) start()
    }

    fun stop() {
        running.set(false)
        interrupt()
    }

    private fun stopInternal() {
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioRecord = null
        audioTrack = null
        AudioLink.clear()
    }

    fun setEqGain(index: Int, gainDb: Float) = dsp.setEqGain(index, gainDb)
    fun resetEq() = dsp.resetEq()
    fun getEqGains() = dsp.getEqGains()
}
