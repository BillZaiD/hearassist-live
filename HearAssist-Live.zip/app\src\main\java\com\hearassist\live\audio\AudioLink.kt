package com.hearassist.live.audio

import com.hearassist.live.audio.dsp.DspProcessor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AudioLink {
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()

    private val _masterGain = MutableStateFlow(0.3f)
    val masterGain: StateFlow<Float> = _masterGain.asStateFlow()

    private val _inputGain = MutableStateFlow(1.0f)
    val inputGain: StateFlow<Float> = _inputGain.asStateFlow()

    private val _eqGains = MutableStateFlow(FloatArray(9) { 0f })
    val eqGains: StateFlow<FloatArray> = _eqGains.asStateFlow()

    @Volatile
    var dspProcessor: DspProcessor? = null

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    fun setMuted(muted: Boolean) {
        _muted.value = muted
        dspProcessor?.muted = muted
    }

    fun toggleMute() {
        setMuted(!_muted.value)
    }

    fun setMasterGain(gain: Float) {
        val clamped = gain.coerceIn(0f, 1f)
        _masterGain.value = clamped
        dspProcessor?.masterGain = clamped
    }

    fun setInputGain(gain: Float) {
        val clamped = gain.coerceIn(0f, 4f)
        _inputGain.value = clamped
        dspProcessor?.inputGain = clamped
    }

    fun setEqGain(index: Int, gainDb: Float) {
        if (index < 0 || index >= 9) return
        val clamped = gainDb.coerceIn(-12f, 12f)
        val arr = _eqGains.value.copyOf()
        arr[index] = clamped
        _eqGains.value = arr
        dspProcessor?.setEqGain(index, clamped)
    }

    fun resetEq() {
        _eqGains.value = FloatArray(9) { 0f }
        dspProcessor?.resetEq()
    }

    fun applyPresetSpeech() {
        val arr = floatArrayOf(-2f, -1f, 0f, 3f, 4f, 3f, 2f, 1f, 0f)
        _eqGains.value = arr
        arr.forEachIndexed { i, v -> dspProcessor?.setEqGain(i, v) }
    }

    fun applyPresetQuiet() {
        val arr = floatArrayOf(1f, 1f, 0f, -1f, -2f, -2f, -1f, 0f, 0f)
        _eqGains.value = arr
        arr.forEachIndexed { i, v -> dspProcessor?.setEqGain(i, v) }
    }

    fun applyAllToProcessor() {
        dspProcessor?.muted = _muted.value
        dspProcessor?.masterGain = _masterGain.value.coerceIn(0f, 1f)
        dspProcessor?.inputGain = _inputGain.value.coerceIn(0f, 4f)
        val gains = _eqGains.value
        for (i in gains.indices) {
            dspProcessor?.setEqGain(i, gains[i])
        }
    }

    fun clear() {
        _isListening.value = false
        dspProcessor = null
    }
}
