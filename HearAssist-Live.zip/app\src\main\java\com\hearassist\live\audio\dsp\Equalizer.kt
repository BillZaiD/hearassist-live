package com.hearassist.live.audio.dsp

class Equalizer(sampleRate: Int = 48000) {
    private val freqs = floatArrayOf(125f, 250f, 500f, 1000f, 2000f, 3000f, 4000f, 6000f, 8000f)
    private val filters = Array(freqs.size) { Biquad() }
    private val gainsDb = FloatArray(freqs.size) { 0f }
    private val srD = sampleRate.toDouble()

    init {
        reset()
    }

    fun setGain(index: Int, gainDb: Float) {
        if (index < 0 || index >= gainsDb.size) return
        gainsDb[index] = gainDb
        filters[index].setPeaking(srD, freqs[index].toDouble(), 0.7, gainDb.toDouble())
    }

    fun getGains(): FloatArray = gainsDb.copyOf()

    fun reset() {
        for (i in gainsDb.indices) {
            gainsDb[i] = 0f
            filters[i].setFlat()
            filters[i].reset()
        }
    }

    fun process(x: Double): Double {
        var y = x
        for (f in filters) {
            y = f.process(y)
        }
        return y
    }
}
