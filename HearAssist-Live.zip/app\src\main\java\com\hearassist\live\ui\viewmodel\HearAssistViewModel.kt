package com.hearassist.live.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hearassist.live.audio.AudioLink
import com.hearassist.live.audio.DeviceRouter
import com.hearassist.live.data.SettingsDataStore
import com.hearassist.live.service.HearAssistService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class HearAssistViewModel(app: Application) : AndroidViewModel(app) {
    private val deviceRouter = DeviceRouter(app)
    private val settings = SettingsDataStore(app)

    val isListening: StateFlow<Boolean> = AudioLink.isListening
    val muted: StateFlow<Boolean> = AudioLink.muted
    val masterGain: StateFlow<Float> = AudioLink.masterGain
    val inputGain: StateFlow<Float> = AudioLink.inputGain
    val eqGains: StateFlow<FloatArray> = AudioLink.eqGains

    private val _micName = MutableStateFlow("Default Microphone")
    val micName: StateFlow<String> = _micName.asStateFlow()

    private val _outName = MutableStateFlow("Default Output")
    val outName: StateFlow<String> = _outName.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        deviceRouter.start()
        deviceRouter.setListener {
            updateDevices()
        }
        updateDevices()
        viewModelScope.launch {
            settings.masterGain.collect { gain ->
                if (!AudioLink.isListening.value) {
                    AudioLink.setMasterGain(gain)
                }
            }
        }
        viewModelScope.launch {
            settings.inputGain.collect { gain ->
                AudioLink.setInputGain(gain)
            }
        }
        viewModelScope.launch {
            settings.eqGains.collect { gains ->
                for (i in gains.indices) {
                    AudioLink.setEqGain(i, gains[i])
                }
            }
        }
    }

    private fun updateDevices() {
        val ins = deviceRouter.getInputDevices()
        if (ins.isNotEmpty()) _micName.value = ins.first().name
        val outs = deviceRouter.getOutputDevices()
        if (outs.isNotEmpty()) _outName.value = outs.first().name
    }

    fun startListening(context: Context) {
        val intent = Intent(context, HearAssistService::class.java)
        context.startForegroundService(intent)
    }

    fun stopListening(context: Context) {
        val intent = Intent(context, HearAssistService::class.java).setAction(HearAssistService.ACTION_STOP)
        context.startService(intent)
    }

    fun toggleMute() {
        AudioLink.toggleMute()
    }

    fun setMasterGain(v: Float) {
        AudioLink.setMasterGain(v)
        viewModelScope.launch { settings.saveMasterGain(v) }
    }

    fun setInputGain(v: Float) {
        AudioLink.setInputGain(v)
        viewModelScope.launch { settings.saveInputGain(v) }
    }

    fun setEqGain(i: Int, v: Float) {
        AudioLink.setEqGain(i, v)
        viewModelScope.launch { settings.saveEqGains(AudioLink.eqGains.value) }
    }

    fun resetEq() {
        AudioLink.resetEq()
        viewModelScope.launch { settings.saveEqGains(AudioLink.eqGains.value) }
    }

    fun applyPresetSpeech() {
        AudioLink.applyPresetSpeech()
        viewModelScope.launch { settings.saveEqGains(AudioLink.eqGains.value) }
    }

    fun applyPresetQuiet() {
        AudioLink.applyPresetQuiet()
        viewModelScope.launch { settings.saveEqGains(AudioLink.eqGains.value) }
    }

    override fun onCleared() {
        deviceRouter.stop()
        super.onCleared()
    }
}
