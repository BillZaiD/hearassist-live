package com.hearassist.live.audio.model

data class AudioConfig(
    val sampleRate: Int = 48000,
    val channelConfig: Int = android.media.AudioFormat.CHANNEL_IN_MONO,
    val audioFormat: Int = android.media.AudioFormat.ENCODING_PCM_16BIT,
    val bufferSizeInBytes: Int = 0,
    val framesPerBuffer: Int = 256
)

data class Band(
    val freq: Float,
    val gainDb: Float = 0f
)
