package com.hearassist.live.ui.eq

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hearassist.live.R
import androidx.compose.ui.res.stringResource
import com.hearassist.live.ui.theme.Background
import com.hearassist.live.ui.theme.Primary
import com.hearassist.live.ui.theme.Surface
import com.hearassist.live.ui.viewmodel.HearAssistViewModel

@Composable
fun EqualizerScreen(viewModel: HearAssistViewModel) {
    val gains by viewModel.eqGains.collectAsState()
    val freqs = listOf("125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "3 kHz", "4 kHz", "6 kHz", "8 kHz")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = Primary)
            Text(stringResource(R.string.eq), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.presets), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = { viewModel.applyPresetSpeech() }, label = { Text(stringResource(R.string.preset_speech_clarity)) })
                    AssistChip(onClick = { viewModel.applyPresetQuiet() }, label = { Text(stringResource(R.string.preset_quiet_environment)) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.resetEq() }, shape = RoundedCornerShape(12.dp)) {
                        Text(stringResource(R.string.flat_eq))
                    }
                    FilledTonalButton(onClick = { viewModel.resetEq() }, shape = RoundedCornerShape(12.dp)) {
                        Text(stringResource(R.string.reset_eq))
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text("تعديل الترددات يدوياً", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                gains.forEachIndexed { idx, g ->
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(freqs[idx], style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            Text(String.format("%+.1f dB", g), style = MaterialTheme.typography.bodyMedium, color = if (g == 0f) MaterialTheme.colorScheme.onSurfaceVariant else Primary)
                        }
                        Slider(
                            value = g,
                            onValueChange = { viewModel.setEqGain(idx, it) },
                            valueRange = -12f..12f,
                            colors = SliderDefaults.colors(
                                thumbColor = Primary,
                                activeTrackColor = Primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}
