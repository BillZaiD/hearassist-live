package com.hearassist.live.dsp

import com.hearassist.live.audio.dsp.Biquad
import com.hearassist.live.audio.dsp.Limiter
import org.junit.Test
import org.junit.Assert.*

class BiquadTest {
    @Test
    fun peakingFlat() {
        val b = Biquad()
        b.setFlat()
        assertEquals(1.0, b.process(1.0), 1e-12)
    }

    @Test
    fun limiterReduces() {
        val l = Limiter(-6.0f)
        l.setSampleRate(48000)
        var out = 0.0
        for (i in 0..1000) {
            out = l.process(1.0)
        }
        assertTrue(out < 0.6)
    }
}
