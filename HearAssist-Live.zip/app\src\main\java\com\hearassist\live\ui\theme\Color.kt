package com.hearassist.live.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF0F766E)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFF99F6E4)
val OnPrimaryContainer = Color(0xFF00201C)

val Secondary = Color(0xFF3F5D57)
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFC2E8DF)
val OnSecondaryContainer = Color(0xFF1F2825)

val Tertiary = Color(0xFF3C6473)
val OnTertiary = Color(0xFFFFFFFF)
val TertiaryContainer = Color(0xFFC0E8FB)
val OnTertiaryContainer = Color(0xFF001F29)

val Background = Color(0xFFF8FAF9)
val OnBackground = Color(0xFF191C1B)
val Surface = Color(0xFFFFFFFF)
val OnSurface = Color(0xFF191C1B)
val SurfaceVariant = Color(0xFFDAE5E1)
val OnSurfaceVariant = Color(0xFF3F4946)

val Outline = Color(0xFF6F7976)
val Error = Color(0xFFBA1A1A)
val Success = Color(0xFF22C55E)
val Warning = Color(0xFFF59E0B)
