package com.hearassist.live.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

data class AudioDevice(
    val id: Int,
    val name: String,
    val type: Int,
    val isInput: Boolean
)

class DeviceRouter(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var listener: (() -> Unit)? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            listener?.invoke()
        }
    }

    fun start() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        }
        context.registerReceiver(receiver, filter)
    }

    fun stop() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    fun setListener(l: () -> Unit) { listener = l }

    fun getInputDevices(): List<AudioDevice> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            return devices.map { AudioDevice(it.id, it.productName?.toString() ?: it.type.toString(), it.type, true) }
        }
        return emptyList()
    }

    fun getOutputDevices(): List<AudioDevice> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            return devices.map { AudioDevice(it.id, it.productName?.toString() ?: it.type.toString(), it.type, false) }
        }
        return emptyList()
    }

    fun isWiredHeadsetOn(): Boolean {
        return audioManager.isWiredHeadsetOn
    }
}
