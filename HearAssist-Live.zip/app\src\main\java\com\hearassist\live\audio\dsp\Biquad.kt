package com.hearassist.live.audio.dsp

import kotlin.math.cos
import kotlin.math.sin

enum class BiquadType {
    PEAKING, LOW_SHELF, HIGH_SHELF, LOW_PASS, HIGH_PASS
}

data class BiquadCoeffs(
    var b0: Double = 1.0,
    var b1: Double = 0.0,
    var b2: Double = 0.0,
    var a1: Double = 0.0,
    var a2: Double = 0.0
)

class Biquad {
    private val coeffs = BiquadCoeffs()
    private var x1: Double = 0.0
    private var x2: Double = 0.0
    private var y1: Double = 0.0
    private var y2: Double = 0.0

    @Synchronized
    fun setPeaking(sampleRate: Double, centerFreq: Double, q: Double, gainDb: Double) {
        val a = Math.pow(10.0, gainDb / 40.0)
        val w0 = 2.0 * Math.PI * centerFreq / sampleRate
        val cosw0 = cos(w0)
        val sinw0 = sin(w0)
        val alpha = sinw0 / (2.0 * q)
        val b0 = 1.0 + alpha * a
        val b1 = -2.0 * cosw0
        val b2 = 1.0 - alpha * a
        val a0 = 1.0 + alpha / a
        val a1 = -2.0 * cosw0
        val a2 = 1.0 - alpha / a
        coeffs.b0 = b0 / a0
        coeffs.b1 = b1 / a0
        coeffs.b2 = b2 / a0
        coeffs.a1 = a1 / a0
        coeffs.a2 = a2 / a0
    }

    @Synchronized
    fun setFlat() {
        coeffs.b0 = 1.0; coeffs.b1 = 0.0; coeffs.b2 = 0.0
        coeffs.a1 = 0.0; coeffs.a2 = 0.0
    }

    fun process(x: Double): Double {
        val y = coeffs.b0 * x + coeffs.b1 * x1 + coeffs.b2 * x2 - coeffs.a1 * y1 - coeffs.a2 * y2
        x2 = x1
        x1 = x
        y2 = y1
        y1 = y
        return y
    }

    fun reset() {
        x1 = 0.0; x2 = 0.0; y1 = 0.0; y2 = 0.0
    }
}
