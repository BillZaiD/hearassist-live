package com.hearassist.live.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hearassist_settings")

class SettingsDataStore(private val context: Context) {
    companion object {
        val MASTER_GAIN = floatPreferencesKey("master_gain")
        val INPUT_GAIN = floatPreferencesKey("input_gain")
        val EQ_BAND_0 = floatPreferencesKey("eq_0")
        val EQ_BAND_1 = floatPreferencesKey("eq_1")
        val EQ_BAND_2 = floatPreferencesKey("eq_2")
        val EQ_BAND_3 = floatPreferencesKey("eq_3")
        val EQ_BAND_4 = floatPreferencesKey("eq_4")
        val EQ_BAND_5 = floatPreferencesKey("eq_5")
        val EQ_BAND_6 = floatPreferencesKey("eq_6")
        val EQ_BAND_7 = floatPreferencesKey("eq_7")
        val EQ_BAND_8 = floatPreferencesKey("eq_8")
    }

    val masterGain: Flow<Float> = context.dataStore.data.map { it[MASTER_GAIN] ?: 0.3f }
    val inputGain: Flow<Float> = context.dataStore.data.map { it[INPUT_GAIN] ?: 1.0f }
    val eqGains: Flow<FloatArray> = context.dataStore.data.map { prefs ->
        floatArrayOf(
            prefs[EQ_BAND_0] ?: 0f,
            prefs[EQ_BAND_1] ?: 0f,
            prefs[EQ_BAND_2] ?: 0f,
            prefs[EQ_BAND_3] ?: 0f,
            prefs[EQ_BAND_4] ?: 0f,
            prefs[EQ_BAND_5] ?: 0f,
            prefs[EQ_BAND_6] ?: 0f,
            prefs[EQ_BAND_7] ?: 0f,
            prefs[EQ_BAND_8] ?: 0f
        )
    }

    suspend fun saveMasterGain(gain: Float) {
        context.dataStore.edit { it[MASTER_GAIN] = gain.coerceIn(0f, 1f) }
    }

    suspend fun saveInputGain(gain: Float) {
        context.dataStore.edit { it[INPUT_GAIN] = gain.coerceIn(0f, 4f) }
    }

    suspend fun saveEqGains(gains: FloatArray) {
        context.dataStore.edit { prefs ->
            prefs[EQ_BAND_0] = gains.getOrNull(0) ?: 0f
            prefs[EQ_BAND_1] = gains.getOrNull(1) ?: 0f
            prefs[EQ_BAND_2] = gains.getOrNull(2) ?: 0f
            prefs[EQ_BAND_3] = gains.getOrNull(3) ?: 0f
            prefs[EQ_BAND_4] = gains.getOrNull(4) ?: 0f
            prefs[EQ_BAND_5] = gains.getOrNull(5) ?: 0f
            prefs[EQ_BAND_6] = gains.getOrNull(6) ?: 0f
            prefs[EQ_BAND_7] = gains.getOrNull(7) ?: 0f
            prefs[EQ_BAND_8] = gains.getOrNull(8) ?: 0f
        }
    }
}
