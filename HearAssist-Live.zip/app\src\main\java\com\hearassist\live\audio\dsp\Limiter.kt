package com.hearassist.live.audio.dsp

import kotlin.math.abs
import kotlin.math.max

class Limiter(thresholdDb: Float = -1.0f, private val releaseMs: Float = 50f) {
    private val threshold = Math.pow(10.0, thresholdDb.toDouble() / 20.0)
    private var gain: Double = 1.0
    private var sampleRate: Int = 48000

    fun setSampleRate(sr: Int) {
        sampleRate = sr
    }

    fun process(x: Double): Double {
        val ax = abs(x)
        if (ax * gain > threshold) {
            gain = threshold / ax
        } else {
            val coeff = Math.exp(-1.0 / (sampleRate * releaseMs / 1000.0))
            gain = coeff * gain + (1.0 - coeff) * 1.0
            if (gain > 1.0) gain = 1.0
        }
        return x * gain
    }

    fun reset() {
        gain = 1.0
    }
}
