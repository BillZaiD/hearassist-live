package com.hearassist.live

import android.app.Application

class HearAssistApp : Application()
